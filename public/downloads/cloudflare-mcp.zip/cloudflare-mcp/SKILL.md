# Cloudflare MCP

Manage the entire Cloudflare API through a token-efficient MCP server with just two tools.

## Files
- `SKILL.md` - The skill definition

## Installation
Copy `SKILL.md` into your agent's skills directory.
